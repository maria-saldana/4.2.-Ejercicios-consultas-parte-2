db.empleados.insertMany([
    { _id: 1, nombre: "Ana", edad: 25, depto_id: 101, proyectos: ["Alpha", "Beta"] },
    { _id: 2, nombre: "Luis", edad: 42, depto_id: 102, proyectos: ["Gamma"] },
    { _id: 3, nombre: "Carlos", edad: 33, depto_id: 101, proyectos: ["Alpha"] },
    { _id: 4, nombre: "Laura", edad: 28, depto_id: 103, proyectos: [] },
    { _id: 5, nombre: "Pedro", edad: 51, depto_id: 104, proyectos: ["Expansión"] },
    { _id: 6, nombre: "Julia", edad: 26, depto_id: 102, proyectos: ["Gamma", "Presentación"] },
    { _id: 7, nombre: "Mario", edad: 38, depto_id: 101, proyectos: ["Beta"] },
    { _id: 8, nombre: "Carla", edad: 29, depto_id: 103, proyectos: [] }
])
db.departamentos.insertMany([
    { _id: 101, nombre: "Desarrollo" },
    { _id: 102, nombre: "Marketing" },
    { _id: 103, nombre: "RRHH" },
    { _id: 104, nombre: "Dirección" }
])

// Parte A – Consultas simples y expresiones regulares
//1. Mostrar los empleados cuyo nombre contiene la letra "a" dos veces (no importa si mayúscula o minúscula).
db.empleados.find({nombre: /(a.*a)/i})

//2. Mostrar solo nombre y proyectos de los empleados cuyo nombre termina en "o".
db.empleados.find({nombre:/o$/i}, {_id:0, nombre: 1, proyectos:1})

//3. Mostrar todos los empleados que no pertenecen a los departamentos "RRHH" ni "Dirección" (usar $lookup y $nin).
db.empleados.aggregate([{$lookup: {from: 'departamentos', localField: "depto_id", 
    foreignField: "_id", as: "depto"}},{$unwind: '$depto'}, 
    {$match: {'depto.nombre': {$nin: ['RRHH', 'Dirección']}}}])

//Parte B – Modificación y limpieza
//4. Eliminar el campo proyectos de los empleados cuyo array está vacío.
db.empleados.updateMany({proyectos: {$size: 0}}, {$unset: { proyectos: "" }})

//5. Agregar un campo activo: true solo a los empleados con edad menor a 40.
db.empleados.updateMany({edad: {$lt: 40}}, {$set: {activo:true}})

// Parte C – Agregación avanzada
//6. Usar $lookup, $unwind y $group para mostrar cuántos empleados hay por nombre de departamento (ordenados de mayor a menor).
db.empleados.aggregate([{$lookup: {from: 'departamentos', localField: 'depto_id', foreignField: '_id', 
    as: 'depto'}}, {$unwind: '$depto'}, {$group: {_id: '$depto.nombre', cantidad_por_depto: {$sum:1}}},
    {$sort: {cantidad_por_depto: -1}}])

//7. Usar $unwind + $group para mostrar cuántas veces aparece cada proyecto en total.
db.empleados.aggregate([{$unwind: '$proyectos'} ,
    {$group: {_id: '$proyectos' , cantidad_por_proyectos: {$sum:1}}}])

// 8. Mostrar cada proyecto junto con una lista de nombres de empleados asignados a ese proyecto (sin repetir el nombre del proyecto).
db.empleados.aggregate([ {$unwind: '$proyectos'},
    {$group: {_id: '$proyectos', empleados: {$push: '$nombre'}}},
    {$project: {_id: 0, proyecto: '$_id', empleados: 1}}])

// Parte D – Consultas complejas
//9. Mostrar los empleados que tienen exactamente 2 proyectos (usar $match + $expr + $size).
db.empleados.aggregate({$match: {$expr: {$eq: [{$size: '$proyectos'}, 2]}}})

//10. Mostrar todos los empleados junto con su nombre completo (nombre_completo: nombre + " del dpto. " nombre del departamento), usando $lookup y $project.
db.empleados.aggregate([{$lookup:{from: 'departamentos', localField: 'depto_id', 
    foreignField: '_id', as: 'depto'}}, {$unwind: '$depto'}, 
    {$project: {_id: 0, nombre_completo: {$concat: ['$nombre', ' del departamento: ', '$depto.nombre']}}}])