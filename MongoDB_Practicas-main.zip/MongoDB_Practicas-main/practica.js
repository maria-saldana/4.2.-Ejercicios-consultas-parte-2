// =======================================
// Base de datos: JS1
// =======================================

db = db.getSiblingDB('JS1');

// =======================================
// COLECCIÓN: productos
// =======================================

db.productos.insertMany([
    { nombre: "Laptop", categoria: "Tecnología", precio: 1200 },
    { nombre: "Teléfono", categoria: "Tecnología", precio: 800 },
    { nombre: "Audífonos", categoria: "Tecnología", precio: 100 },
    { nombre: "Mesa", categoria: "Muebles", precio: 300 },
    { nombre: "Silla", categoria: "Muebles", precio: 150 }
]);

// ============================
// EJERCICIO 1 – forEach
// ============================

print("Ejercicio 1 - Precio mínimo");
let precioMinimo = null;
db.productos.find().forEach(function(producto) {
    if (precioMinimo === null || producto.precio < precioMinimo) {
        precioMinimo = producto.precio;
    }
});
print("El precio mínimo es: $" + precioMinimo);

print("\nEjercicio 2 - Precio promedio");
let sumaPrecios = 0;
let cantidadProductos = 0;
db.productos.find().forEach(function(producto) {
    sumaPrecios += producto.precio;
    cantidadProductos++;
});
let promedio = sumaPrecios / cantidadProductos;
print("El precio promedio es: $" + promedio.toFixed(2));

print("\nEjercicio 3 - Productos ordenados por precio (mayor a menor)");
db.productos.find().sort({ precio: -1 }).forEach(function(producto) {
    print("Producto: " + producto.nombre + " | Precio: $" + producto.precio);
});

print("\nEjercicio 4 - Producto más caro por categoría");
let productosPorCategoria = {};
db.productos.find().forEach(function(producto) {
    let cat = producto.categoria;
    if (!productosPorCategoria[cat] || producto.precio > productosPorCategoria[cat].precio) {
        productosPorCategoria[cat] = producto;
    }
});
for (let categoria in productosPorCategoria) {
    let prod = productosPorCategoria[categoria];
    print("Categoría: " + categoria);
    print(" Producto más caro: " + prod.nombre + " | Precio: $" + prod.precio);
    print("------------------------------------");
}

// ============================
// COLECCIÓN: trabajadores
// ============================

db.trabajadores.insertMany([
    { nombre: "Lucía", departamento: "Ventas", salario: 3000 },
    { nombre: "Carlos", departamento: "Ventas", salario: 2500 },
    { nombre: "Sofía", departamento: "Marketing", salario: 2800 },
    { nombre: "Miguel", departamento: "Marketing", salario: 3200 },
    { nombre: "Ana", departamento: "Finanzas", salario: 4000 }
]);

// ============================
// EJERCICIO 2 – hasNext y next
// ============================

print("\nEjercicio 1 - Salario mínimo:");
let cursor1 = db.trabajadores.find();
let salarioMin = null;
while (cursor1.hasNext()) {
    let trabajador = cursor1.next();
    if (salarioMin === null || trabajador.salario < salarioMin) {
        salarioMin = trabajador.salario;
    }
}
print("El salario mínimo es: $" + salarioMin);

print("\nEjercicio 2 - Salario promedio:");
let cursor2 = db.trabajadores.find();
let totalSalario = 0;
let cantidadTrabajadores = 0;
while (cursor2.hasNext()) {
    let trabajador = cursor2.next();
    totalSalario += trabajador.salario;
    cantidadTrabajadores++;
}
let promedio_2 = totalSalario / cantidadTrabajadores;
print("El salario promedio es: $" + promedio_2.toFixed(2));

print("\nEjercicio 3 - Trabajadores ordenados por salario (mayor a menor):");
let cursor3 = db.trabajadores.find().sort({ salario: -1 });
while (cursor3.hasNext()) {
    let t = cursor3.next();
    print("Trabajador: " + t.nombre + " | Departamento: " + t.departamento + " | Salario: $" + t.salario);
}

print("\nEjercicio 4 - Trabajador con mayor salario por departamento:");
let cursor4 = db.trabajadores.find();
let mejorPorDepto = {};
while (cursor4.hasNext()) {
    let t = cursor4.next();
    let depto = t.departamento;
    if (!mejorPorDepto[depto] || t.salario > mejorPorDepto[depto].salario) {
        mejorPorDepto[depto] = t;
    }
}
for (let depto in mejorPorDepto) {
    let t = mejorPorDepto[depto];
    print("Departamento: " + depto);
    print("Trabajador: " + t.nombre + " | Salario: $" + t.salario);
}

// ============================
// COLECCIÓN: libros
// ============================

db.libros.insertMany([
    { titulo: "Cien Años de Soledad", autor: "Gabriel García Márquez", genero: "Ficción", paginas: 417 },
    { titulo: "Sapiens", autor: "Yuval Noah Harari", genero: "Historia", paginas: 498 },
    { titulo: "El Principito", autor: "Antoine de Saint-Exupéry", genero: "Ficción", paginas: 96 },
    { titulo: "Breves Respuestas a Grandes Preguntas", autor: "Stephen Hawking", genero: "Ciencia", paginas: 256 },
    { titulo: "El Universo en una Cáscara de Nuez", autor: "Stephen Hawking", genero: "Ciencia", paginas: 224 }
]);

// ============================
// EJERCICIO 3 – toArray
// ============================

print("\nEjercicio 1 - Mínimo número de páginas:");
let libros = db.libros.find().toArray();
let minPaginas = libros[0].paginas;
for (let i = 1; i < libros.length; i++) {
    if (libros[i].paginas < minPaginas) {
        minPaginas = libros[i].paginas;
    }
}
print("El mínimo número de páginas es: " + minPaginas);

print("\nEjercicio 2 - Promedio de páginas:");
let totalPaginas = 0;
for (let i = 0; i < libros.length; i++) {
    totalPaginas += libros[i].paginas;
}
let promedio_paginas = totalPaginas / libros.length;
print("El promedio de páginas es: " + promedio_paginas.toFixed(2));

print("\nEjercicio 3 - Libros ordenados por páginas (mayor a menor):");
let librosOrdenados = libros.sort((a, b) => b.paginas - a.paginas);
for (let i = 0; i < librosOrdenados.length; i++) {
    let l = librosOrdenados[i];
    print("Libro: " + l.titulo + " | Páginas: " + l.paginas);
}

print("\nEjercicio 4 - Libro con más páginas por género:");
let masPaginasPorGenero = {};
for (let i = 0; i < libros.length; i++) {
    let libro = libros[i];
    let genero = libro.genero;
    if (!masPaginasPorGenero[genero] || libro.paginas > masPaginasPorGenero[genero].paginas) {
        masPaginasPorGenero[genero] = libro;
    }
}
for (let genero in masPaginasPorGenero) {
    let l = masPaginasPorGenero[genero];
    print("Género: " + genero);
    print("Título: " + l.titulo + " | Páginas: " + l.paginas);
}
