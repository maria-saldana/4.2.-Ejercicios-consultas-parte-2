db.empleados.insertMany([
    {nombre: "Ana", apellido: "Gomez", edad: 28, salario: 120000, area: "Sistemas", proyectos: ["Alpha", "Beta"]},
    {nombre: "Luis", apellido: "Martinez", edad: 35, salario: 100000, area: "Marketing", proyectos: ["Campaña 2024"]},
    {nombre: "Carlos", apellido: "Diaz", edad: 40, salario: 130000, area: "Sistemas", proyectos: ["Alpha"]},
    {nombre: "Laura", apellido: "Sosa", edad: 25, salario: 90000, area: "RRHH", proyectos: []},
    {nombre: "Pedro", apellido: "Fernandez", edad: 50, salario: 180000, area: "Dirección", proyectos: ["Expansión"]}
])

//Mostrar nombre, apellido y salario de todos los empleados ordenados por salario de mayor a menor.
db.empleados.aggregate([{$project: {nombre:1, apellido:1, salario:1}},{$sort: {salario:-1}}]);

//Mostrar el nombre y la cantidad de proyectos asignados por cada empleado (usar $project).
db.empleados.aggregate([{$project: {_id: 0, nombre: 1, cantidadProyectos: { $size: "$proyectos" }}}]);

//Obtener el promedio de salario por área.
db.empleados.aggregate([{$group: {_id: "$area", promedioArea: { $avg: '$salario' }}}]);

//Aumentar un 5% el salario de todos los empleados del área "Sistemas".
db.empleados.updateMany({area: "Sistemas"}, [{$set: {salario: {$multiply: ["$salario", 1.05]}}}]);

//Agregar un campo activo: true solo a los empleados menores de 45 años.
db.empleados.updateMany({edad: {$lt: 45}}, {$set: {activo: true}})

//Mostrar los empleados cuyo apellido contiene la letra "z", sin importar mayúsculas.
db.empleados.find({apellido : /z/i})

//Mostrar el nombre completo (campo nombre_completo) de todos los empleados, uniendo nombre y apellido en un solo campo.
db.empleados.aggregate([{$project: {_id:0, nombre_completo: {$concat: ['$nombre', '-', '$apellido']}}}])

//1. Mostrar el nombre completo de todos los empleados, uniendo nombre y apellido (campo nuevo nombre_completo, solo en la salida).
db.empleados.aggregate([{$project: {_id:0, nombre_completo: {$concat: ['$nombre', '-', '$apellido']}}}])

//2. Aumentar un 8% el salario de los empleados del área "Marketing".
db.empleados.updateMany({area: 'Marketing'}, [{$set: {salario: {$multiply: ['$salario', 1.08]}}}])

//3. Obtener el promedio de salario por cada área.
db.empleados.aggregate([{$group: {_id: '$area', promedioArea: {$avg: '$salario'}}}])

//4. Agregar un campo activo: true a todos los empleados menores de 35 años.
db.empleados.updateMany({edad: {$lt: 35}}, {$set: {activo: true}})

//5. Mostrar los empleados ordenados por salario de mayor a menor, solo con nombre y salario.
db.empleados.aggregate([{$project: {_id:0, nombre:1, salario:1}},{$sort: {salario: -1}}])

//6. Calcular el salario anual de cada empleado (campo nuevo virtual salario_anual), sin modificar datos.
db.empleados.aggregate([{$project: { nombre: 1, salario: 1, salario_anual: { $multiply: ["$salario", 12] }}}])

//7. Eliminar el campo proyectos de todos los empleados del área "RRHH".
db.empleados.updateMany({area: 'RRHH'}, {$unset: {proyectos: ""}})

//8. Ver cuántos empleados hay por área (mostrar nombre del área y cantidad).
db.empleados.aggregate([{$group: {_id: '$area', empleadosArea: {$sum: 1}}}])

//9. Agregar un campo senior: true solo a los empleados con edad mayor a 45.
db.empleados.updateMany({edad: {$gt: 45}}, {$set: {senior: true}})

//10. Reemplazar todos los nombres "Pedro" por "Pedro Luis".
db.empleados.updateMany({nombre: 'Pedro'},{$set: {nombre: 'Pedro Luis'}})