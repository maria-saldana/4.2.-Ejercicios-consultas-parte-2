// Colección: empleados
db.trabajadores.insertMany([
    {_id: 1, nombre: "Ana", area_id: 10, proyectos: ["Alpha", "Beta"]},
    {_id: 2, nombre: "Luis", area_id: 20, proyectos: ["Campaña 2024"]},
    {_id: 3, nombre: "Carlos", area_id: 10, proyectos: ["Alpha"]},
    {_id: 4, nombre: "Laura", area_id: 30, proyectos: []},
    {_id: 5, nombre: "Pedro", area_id: 40, proyectos: ["Expansión"]}
])

// Colección: areas
db.areas.insertMany([
    {_id: 10, nombre: "Sistemas"},
    {_id: 20, nombre: "Marketing"},
    {_id: 30, nombre: "RRHH"},
    {_id: 40, nombre: "Dirección"}
])
//1. Hacer un $lookup para mostrar cada empleado junto al nombre del área a la que pertenece.
db.trabajadores.aggregate([{$lookup: {from: 'areas', localField: 'area_id',
    foreignField: '_id', as: 'trabajadoresPorArea'}},{$unwind: '$trabajadoresPorArea'}, 
    {$project: {_id: 0, nombre_trabajador: '$nombre', nombre_area: '$trabajadoresPorArea.nombre'}}])

//2. Descomponer el array de proyectos ($unwind) para que cada proyecto esté en una fila distinta.
db.trabajadores.aggregate([{$unwind: '$proyectos'}, {$project:{_id:0, proyectos: '$proyectos'} }])

//3. Contar cuántos empleados hay por cada área (usando $lookup y $group).
db.trabajadores.aggregate([{$lookup: {from: 'areas', localField: 'area_id', 
    foreignField: '_id', as: 'trabajadoresPorArea'}}, {$unwind: '$trabajadoresPorArea'}, 
    {$group: {_id: '$trabajadoresPorArea.nombre', trabajadoresPorArea: {$sum: 1}}}])

//4. Mostrar solo el nombre de los empleados y los nombres de las áreas, pero solo de aquellos que tienen al menos 1 proyecto asignado.
db.trabajadores.aggregate([{$match: {$expr: {$gt: [{$size: '$proyectos'}, 0]}}},{$lookup: {from: 'areas', localField: 'area_id', 
    foreignField: '_id', as: 'trabajadoresPorArea'}}, {$unwind: '$trabajadoresPorArea'}, 
    {$project: {_id: 0, nombre_trabajador: '$nombre', nombre_area: '$trabajadoresPorArea.nombre'}}])

//5. Mostrar los nombres de todos los proyectos únicos que hay en la empresa (puede haber repetidos en arrays distintos).
db.trabajadores.aggregate([{$unwind: '$proyectos'}, {$group: {_id: '$proyectos'}}, 
    {$project: {_id: 0, proyecto: '$_id'}}])

//6. Combinar $lookup, $unwind y $group para mostrar cuántos empleados trabajan en cada proyecto (por nombre del proyecto).
db.trabajadores.aggregate([{$unwind: '$proyectos'}, 
    {$group: {_id: '$proyectos', empleadosPorProyecto: {$sum: 1}}}, 
    {$project:{_id:0, proyecto: '$_id', empleadosPorProyecto: 1}}])

//7. Mostrar nombre del trabajador y nombre del área, pero solo para quienes trabajan en la "Dirección" (usar $lookup + $match).
db.trabajadores.aggregate([{$lookup: {from: 'areas', localField: 'area_id',
    foreignField: '_id', as: 'area'}}, {$unwind: '$area'}, {$match: {'area.nombre': 'Dirección'}},
    {$project: {_id: 0, nombre_trabajador: '$nombre', nombre_area: '$area.nombre'}}])

//8. Mostrar cada proyecto y la lista de nombres de los trabajadores que están asignados a él (sin repetir proyectos, usando $group y $push).
db.trabajadores.aggregate([{$unwind: '$proyectos'},
    {$group: { _id: '$proyectos', empleados: {$push: '$nombre'}}},
    {$project: {_id: 0, proyecto: '$_id', empleados: 1}}])

//9. Mostrar los trabajadores cuyo nombre termina en la letra "s", sin importar mayúsculas (expresión regular).
db.trabajadores.find({nombre: /s$/i})

//10.  Eliminar el campo proyectos de los trabajadores cuyo array está vacío.
db.trabajadores.updateMany({proyectos: { $exists: true, $size: 0 }}, {$unset: { proyectos: "" }})

//11. Usar $lookup para mostrar todos los trabajadores junto con el nombre del área, ordenados alfabéticamente por área.
db.trabajadores.aggregate([{$lookup: {from: 'areas' ,localField: 'area_id',
    foreignField: '_id', as: 'area'}}, {$unwind: '$area'},
    {$project: {_id: 0, nombre_trabajador: '$nombre', nombre_area: '$area.nombre'}}, 
    {$sort: {nombre_area: -1}}])

//12. Usar $unwind y $group para mostrar cada proyecto y cuántas veces aparece en total (es decir, si hay 3 empleados con el proyecto "Alpha", que diga "Alpha: 3").
db.trabajadores.aggregate([{$unwind: '$proyectos'}, 
    {$group: {_id:'$proyectos', empleadosPorProyecto: {$sum: 1}}},
    {$project: {_id:0, proyecto: '$_id', empleadosPorProyecto: 1}}])

//13. Usar $group para mostrar la cantidad total de proyectos asignados por área (ejemplo: Sistemas tiene 4 proyectos sumando los de sus empleados).
db.trabajadores.aggregate([{$project: {area_id: 1, cantidad_proyectos: {$size: "$proyectos" }}},
    {$group: {_id: "$area_id", totalProyectos: { $sum: "$cantidad_proyectos" }}},
    {$lookup: { from: "areas", localField: "_id", foreignField: "_id", as: "area"}}, 
    {$unwind: "$area"}, {$project: { _id: 0, nombre_area: "$area.nombre", totalProyectos: 1}}])

//14. Mostrar solo los trabajadores que tengan exactamente 1 proyecto asignado (usá $expr y $size en $match).
db.trabajadores.aggregate({$match: {$expr: {$eq: [{$size: '$proyectos'}, 1]}}})

//15. Mostrar solo los nombres y proyectos de los trabajadores cuyo nombre contenga "ar" (como "Carlos" o "Laura").
db.trabajadores.find({nombre: /ar/i}, {nombre: 1, proyectos: 1, _id: 0})