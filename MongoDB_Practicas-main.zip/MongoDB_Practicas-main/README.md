# 📘 Prácticas de MongoDB 

Este repositorio contiene una colección de ejercicios prácticos realizados con **MongoDB** como parte de mi formación en bases de datos NoSQL. Cada carpeta o archivo representa un conjunto de desafíos resueltos usando inserciones, consultas, actualizaciones y operaciones de agregación sobre diferentes estructuras de datos.


## 🧠 Temas trabajados

- Inserción de documentos con `insertMany()`
- Consultas con `find()`, expresiones regulares y filtros lógicos
- Proyección de datos con `project`, `concat`, `size`, etc.
- Agregaciones con `group`, `avg`, `sum`, `sort`
- Unión de colecciones con `$lookup` y desanidado con `$unwind`
- Actualizaciones condicionales con `updateMany()`, `$set`, `$unset`, `$push`, `$inc`
- Eliminación con `deleteMany()`
- Trabajo con estructuras complejas: arrays, objetos embebidos y campos anidados


## 🧰 Tecnologías

- **MongoDB** (usado desde la shell interactiva)
- **JavaScript** para scripts de base de datos


 ## 👩🏼‍💻 Autor

**Lucila Micaela Suarez**  
